

export default function Cleanser() {
    return (
        <div className="cleanserpage">
            <div className='cleanserHeader'/>
            <h1>Your Cart is Empty</h1>
                <p></p>
                
                
       </div>
    )
}