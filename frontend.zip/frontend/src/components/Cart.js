

export default function Cart() {
    return (
        <div className="cartpage">
            <div className='cartHeader'/>
            <h1>Your Cart is Empty</h1>
                <p></p>
                
                
       </div>
    )
}