

export default function About () {
    return (
        <div className="aboutpage">
            <div className="aboutHeader">
                <h1>About Us</h1>
            </div>
            <p>We are the creators of the Glass Skin Refining Serum and the and EYS Collection – 100% Worry Free skincare with formulas that deliver big results with zero compromises. Spa-grade, toxin‑free, delightful, and accessible.</p>
            <p>We are the creators of Acne Spots Dots and the EYS line – easy, fun and affordable Asian Beauty-inspired skincare with no harsh chemicals, dyes, alcohol, parabens or sulfates.</p>                      
            <p>We are the top destination for the very best curation of Asian Beauty products and innovations from cult favorite Asian Beauty brands.</p>        
            <img src="kalos.jpg" alt="kalos" />

    </div>
    )
}





