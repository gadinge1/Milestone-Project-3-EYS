export default function User() {
    return (
        <div className="userpage">
            <div className='userHeader'/>
            <h1>Account</h1>
                <p></p>
                
                
       </div>
    )
}