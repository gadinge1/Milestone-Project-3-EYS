

export default function Home() {
    return (
        <div className="homepage">
            <div className='homepageHeader'/>
            <h1>Start Your Skincare Journey!</h1>
                <p>Skin care is a personal journey and we're here to guide you along the way.</p>
                <p>Skin care is a personal journey and we're here to guide you along the way.</p>
                <p>Check Out our wide array of Asian Beauty Products!</p> 
                <img src="chelsea.jpg" alt="chelsea" />
       </div>

    )

}
